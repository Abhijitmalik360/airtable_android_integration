package com.example.airtable;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AirtableAdapter extends RecyclerView.Adapter<AirtableAdapter.ViewHolder> {
    private List<AirtableResponse.Record> records;

    public AirtableAdapter(List<AirtableResponse.Record> records) {
        this.records = records;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_record, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AirtableResponse.Record record = records.get(position);
        holder.nameTextView.setText(record.getFields().getName());
        holder.ageTextView.setText(String.valueOf(record.getFields().getAge()));
    }

    @Override
    public int getItemCount() {
        return records.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView nameTextView;
        public TextView ageTextView;

        public ViewHolder(View view) {
            super(view);
            nameTextView = view.findViewById(R.id.nameTextView);
            ageTextView = view.findViewById(R.id.ageTextView);
        }
    }
}
