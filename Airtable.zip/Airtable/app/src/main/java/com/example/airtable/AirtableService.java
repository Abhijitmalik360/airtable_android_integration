package com.example.airtable;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Headers;

public interface AirtableService {
    @Headers({
            "Authorization: Bearer patvDSFy7YUMo4WOI.5d201751ca08224a7fe6e994ab6f5c6e86313a0b247d12fe1105821f477d4c93",
            "Content-Type: application/json"
    })
    @GET("v0/appb8DfvgeSzZe1jQ/AppName")
    Call<AirtableResponse> getRecords();
}
