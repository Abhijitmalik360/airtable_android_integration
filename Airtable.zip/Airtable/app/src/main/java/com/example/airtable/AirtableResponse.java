package com.example.airtable;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class AirtableResponse {
    @SerializedName("records")
    private List<Record> records;

    public List<Record> getRecords() {
        return records;
    }

    public void setRecords(List<Record> records) {
        this.records = records;
    }

    public static class Record {
        @SerializedName("fields")
        private Fields fields;

        public Fields getFields() {
            return fields;
        }

        public void setFields(Fields fields) {
            this.fields = fields;
        }

        public static class Fields {
            @SerializedName("ActivityName")

            private String name;

            @SerializedName("ImageUrl")
            private String age;

            public String getAppLink() {
                return AppLink;
            }

            public void setAppLink(String appLink) {
                AppLink = appLink;
            }

            @SerializedName("AppLink")

            private String AppLink;

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public String getAge() {
                return age;
            }

            public void setAge(String age) {
                this.age = age;
            }
        }
    }
}
